﻿using System;

namespace StringCostCalculation
{
    class CalculateCost
    {
        public int MeasureCost(string str, int costForAdd, int costForCopy)
        {
            string createdStr = string.Empty;
            int finalCost = 0;
            for (int i = 0; i < str.Length; i++)
            {
                if (string.IsNullOrEmpty(createdStr))
                {
                    createdStr += str.Substring(i, 1);
                    finalCost += costForAdd;
                }
                else
                {
                    var createdStrLength = createdStr.Length;
                    var isExist = false;
                    if (str.Substring(i).Length < createdStrLength)
                        createdStrLength = str.Substring(i).Length;

                    for (int j = createdStrLength; j > 1; j--)
                    {
                        var subvalue = str.Substring(i, j);
                        if (createdStr.Contains(subvalue))
                        {
                            createdStr += subvalue;
                            finalCost += costForCopy;
                            i = createdStr.Length -1;
                            isExist = true;
                            break;
                        }
                    }

                    if (!isExist)
                    {
                        createdStr += str.Substring(i, 1);
                        finalCost += costForAdd;
                    }

                }

            }
            return finalCost;
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter string to calculate cost:");
            string requiredVal = Console.ReadLine();

            Console.WriteLine("Enter cost to add a character (Should be an integer):");
            int costForAdd = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter cost for copy any substring (Should be an integer):");
            int costForCopy = Convert.ToInt32(Console.ReadLine());

            CalculateCost costObj = new CalculateCost();
            int cost = costObj.MeasureCost(requiredVal, costForAdd, costForCopy);

            Console.WriteLine("Final cost to build the {0} is : {1}", requiredVal, cost);

        }
    }
}
