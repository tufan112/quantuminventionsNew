﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreDemoPOCs.Service;
using CoreDemoPOCs.Web.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace CoreDemoPOCs.Web.Controllers
{
    public class BackendController : Controller
    {
        private ILogger _logger;
        private IDevicesService _service;


        public BackendController(ILogger<BackendController> logger, IDevicesService service)
        {
            _logger = logger;
            _service = service;

        }
        public ActionResult Index()
        {
            List<BackendModel> backendList = new List<BackendModel>();
            try
            {
                var backendEntity = _service.GetBackends();
                if (backendEntity != null && backendEntity.Count > 0)
                {

                    foreach (var x in backendEntity)
                    {
                        backendList.Add(new BackendModel()
                        {
                            Id = x.Id,
                            Name = x.Name,
                            Address = x.Address
                            
                        });
                    }
                }

            }
            catch (Exception ex)
            {

            }

            return View(backendList);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]         
        public ActionResult Create([Bind("Name,Address,Id")] BackendModel backend)
        {
            try
            {
                if (backend != null)
                {
                    Database.Entity.Backend backendEntity = new Database.Entity.Backend()
                    {
                        Name = backend.Name,
                        Address = backend.Address,
                        Id = Guid.NewGuid()                     
                    };
                    _service.AddBackend(backendEntity);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Edit(Guid id)
        {
            BackendModel model = new BackendModel();

            try
            {
                var backendEntity = _service.GetBackend(id);
                if (backendEntity != null)
                {
                    model.Id = backendEntity.Id;
                    model.Name = backendEntity.Name;
                    model.Address = backendEntity.Address;
                    
                }
            }
            catch (Exception ex)
            {

            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Guid id, [Bind("Enabled")] string Enabled, IFormCollection collection)
        {
            try
            {
                var backendEntity = _service.GetBackend(id);
                if (backendEntity != null)
                {
                    BackendModel model = new BackendModel();

                    model.Id = id; 
                    model.Address = collection["Address"];
                    model.Name = collection["Name"]; 
                   
                    if (model != null)
                    {
                        backendEntity.Id = model.Id;
                        backendEntity.Address = model.Address;
                        backendEntity.Name = model.Name;
                        
                        _service.UpdateBackend(id, backendEntity);

                    }
                }
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                return View();
            }
        }
    }
}
