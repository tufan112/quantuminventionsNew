﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreDemoPOCs.Database.Entity;
using CoreDemoPOCs.Service;
using CoreDemoPOCs.Web.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace CoreDemoPOCs.Web.Controllers
{
    public class DeviceController : Controller
    {
        // GET: DeviceController

        private ILogger _logger;
        private IDevicesService _service;


        public DeviceController(ILogger<DeviceController> logger, IDevicesService service)
        {
            _logger = logger;
            _service = service;

        }

        private bool IsAuthenticated()
        {
            return string.IsNullOrEmpty(HttpContext.Session.GetString("Username")) ? false : true; ;

        }

     
        public ActionResult Index()
        {
            if (!IsAuthenticated()) return RedirectToAction("Login", "Account");

            List<DeviceModel> dvList = new List<DeviceModel>();
            try
            {
                var deviceEntity = _service.GetDevices();
                if (deviceEntity != null && deviceEntity.Count > 0)
                {

                    foreach (var x in deviceEntity)
                    {
                        dvList.Add(new DeviceModel()
                        {
                            IMEI = x.IMEI,
                            SIMCard = x.SIMCard,
                            Model = x.Model,
                            Enabled = x.Enabled.ToString()
                        });
                    }
                }

            }
            catch (Exception ex)
            {

            }

            return View(dvList);
        }

        public ActionResult GetDeviceBackend()
        {
            List<DeviceBackend> dvList = new List<DeviceBackend>();
            try
            {
                dvList = _service.GetDeviceBackends();
                //if (deviceEntity != null && deviceEntity.Count > 0)
                //{

                //    foreach (var x in deviceEntity)
                //    {
                //        dvList.Add(new DeviceModel()
                //        {
                //            IMEI = x.IMEI,
                //            SIMCard = x.SIMCard,
                //            Model = x.Model,
                //            Enabled = x.Enabled.ToString()
                //        });
                //    }
                //}

            }
            catch (Exception ex)
            {

            }

            return View(dvList);
        }
        // GET: DeviceController/Details/5
        public ActionResult Details(string id)
        {
            DeviceModel model = new DeviceModel();
            try
            {
                var deviceEntity = _service.GetDevice(id);
                if (deviceEntity != null)
                {
                    model.IMEI = deviceEntity.IMEI;
                    model.Model = deviceEntity.Model;
                    model.SIMCard = deviceEntity.SIMCard;
                    model.Enabled = deviceEntity.Enabled.ToString();
                    model.backends = _service.GetBackendOfDevice(deviceEntity.IMEI);                    
                }
            }
            catch (Exception ex)
            {

            }
            return View(model);
        }



        // GET: DeviceController/Create
        public ActionResult Create()
        {
          //  List<BackendModel> backendList = new List<BackendModel>();
            DeviceModel model = new DeviceModel();
            model.backendList = new List<BackendModel>();
            try
            {
                model.backendList.Add(new BackendModel()
                {
                    Id = Guid.Empty,
                    Name = "Select mapping"

                });

                var backendEntity = _service.GetBackends();
                if (backendEntity != null && backendEntity.Count > 0)
                {

                    foreach (var x in backendEntity)
                    {
                        model.backendList.Add(new BackendModel()
                        {
                            Id = x.Id,
                            Name = x.Name

                        });
                    }
                }

            }
            catch (Exception ex)
            {

            }

           // ViewBag.message = backendList;
            return View(model);
        }

        // POST: DeviceController/Create
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Create([Bind("IMEI,Model,SIMCard,Enabled,Mappedid")] DeviceModel devices)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (devices != null)
                    {
                        Database.Entity.Device deviceEntity = new Database.Entity.Device()
                        {
                            IMEI = devices.IMEI,
                            SIMCard = devices.SIMCard,
                            Model = devices.Model,
                            Enabled = Convert.ToBoolean(devices.Enabled),
                            CreatedDate = DateTime.UtcNow,
                            CreatedBy = "Admin"
                        };
                        _service.AddDevice(deviceEntity);

                        if (devices.Mappedid != Guid.Empty)
                        {
                            Database.Entity.DeviceBackend deviceBackendEntity = new Database.Entity.DeviceBackend()
                            {
                                Id = devices.Mappedid,
                                IMEI = devices.IMEI,
                                MappedDateTime = DateTime.UtcNow
                            };

                            var mappedBackend = _service.GetBackendOfDevice(devices.IMEI);
                            if (mappedBackend != null)
                            {
                                if (mappedBackend.Count > 0)
                                {
                                    _service.UpdateDeviceBackend(deviceBackendEntity);
                                }
                                else
                                {
                                    _service.AddDeviceBackend(deviceBackendEntity);
                                }
                            }
                            else
                            {
                                _service.AddDeviceBackend(deviceBackendEntity);
                            }
                        }
                    }
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    return View();
                }

            }
            catch (Exception ex)
            {
                return View();
            }

        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult CreateDeviceBackend([Bind("IMEI,Id")] DeviceBackend deviceBackend)
        {
            try
            {
                if (deviceBackend != null)
                {

                    _service.AddDeviceBackend(deviceBackend);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult CreateBackend([Bind("Name,Address")] Backend backend)
        {
            try
            {
                if (backend != null)
                {

                    _service.AddBackend(backend);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        // GET: DeviceController/Edit/5
        public ActionResult Edit(string id)
        {
            DeviceModel model = new DeviceModel();
            model.backendList = new List<BackendModel>();
          //  List<BackendModel> backendList = new List<BackendModel>();
            List<BackendModel> backendListOfDevice = new List<BackendModel>();
            try
            {
                model.backendList.Add(new BackendModel()
                {
                    Id = Guid.Empty,
                    Name = "Select mapping"

                });

                var backendEntity = _service.GetBackends();
                if (backendEntity != null && backendEntity.Count > 0)
                {

                    foreach (var x in backendEntity)
                    {
                        model.backendList.Add(new BackendModel()
                        {
                            Id = x.Id,
                            Name = x.Name

                        });
                    }
                }

                var deviceEntity = _service.GetDevice(id);
                if (deviceEntity != null)
                {
                    model.IMEI = deviceEntity.IMEI;
                    model.Model = deviceEntity.Model;
                    model.SIMCard = deviceEntity.SIMCard;
                    model.Enabled = deviceEntity.Enabled.ToString();
                    model.backends = _service.GetBackendOfDevice(deviceEntity.IMEI);
                    //if (backenEntity != null && backenEntity.Count > 0)
                    //{

                    //    foreach (var x in backenEntity)
                    //    {
                    //        backendListOfDevice.Add(new BackendModel()
                    //        {
                    //            Id = x.Id,
                    //            Name = x.Name

                    //        });
                    //    }
                    //}
                    //model.backends = backendListOfDevice;
                }
            }
            catch (Exception ex)
            {

            }
           // ViewBag.message = backendList;
            return View(model);
        }

        // POST: DeviceController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(string id, [Bind("Enabled")] string Enabled, IFormCollection collection)
        {
            try
            {
               
                var deviceEntity = _service.GetDevice(id);
                if (deviceEntity != null)
                {
                    DeviceModel model = new DeviceModel();

                    model.IMEI = id; 
                    model.Model = collection["Model"];
                    model.SIMCard = Convert.ToDouble(collection["SIMCard"]);
                    model.Enabled = Enabled;// collection["Enabled"]; //Convert.ToBoolean(collection["Enabled"][0]);
                    Guid mappedid = Guid.Parse(collection["Mappedid"]);
                    // (DeviceModel)collection;
                    if (model != null)
                    {
                        deviceEntity.IMEI = model.IMEI;
                        deviceEntity.Model = model.Model;
                        deviceEntity.SIMCard = model.SIMCard;
                        deviceEntity.Enabled = Convert.ToBoolean(model.Enabled);
                        _service.UpdateDevice(id, deviceEntity);
                       
                        //if (mappedid != Guid.Empty)
                        //{
                        //    Database.Entity.DeviceBackend deviceBackendEntity = new Database.Entity.DeviceBackend()
                        //    {
                        //        Id = mappedid,
                        //        IMEI = deviceEntity.IMEI,
                        //        MappedDateTime = DateTime.UtcNow
                        //    };

                        //    var mappedBackend = _service.GetBackendOfDevice(deviceEntity.IMEI);
                        //    if (mappedBackend != null)
                        //    {
                        //        var isPresent = mappedBackend.Where(x => x.Id == mappedid).FirstOrDefault();

                        //        if (isPresent!=null)
                        //        {
                        //            var fetchDeviceBackendDetails = _service.GetDeviceBackend(model.IMEI, mappedid);
                        //            if (fetchDeviceBackendDetails != null)
                        //            {

                        //        //IMEI = deviceEntity.IMEI,
                        //        //MappedDateTime = DateTime.UtcNow
                        //        //        _service.UpdateDeviceBackend(deviceBackendEntity);
                        //            }
                        //        }
                        //        else
                        //        {
                        //            _service.AddDeviceBackend(deviceBackendEntity);
                        //        }
                        //    }
                        //    else
                        //    {
                        //        _service.AddDeviceBackend(deviceBackendEntity);
                        //    }


                        //}
                    }
                }

               
                    return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        public ActionResult AddMapping(IDictionary<string, string> addMappingData)
        {
            string iMEI = addMappingData["IMEI"];
            Guid mappedid = Guid.Parse(addMappingData["Mappedid"]);
            try
            {

                if (mappedid != Guid.Empty)
                {
                    var mappedBackend = _service.GetBackendOfDevice(iMEI);
                    if (mappedBackend != null)
                    {
                        var isPresent = mappedBackend.Where(x => x.Id == mappedid).FirstOrDefault();

                        if (isPresent != null)
                        {
                            if (isPresent.Id != Guid.Empty)
                            {
                                 
                                ModelState.AddModelError("", "This mapping is already exist.");
                                TempData["Error"] = "This mapping is already exist.";


                            }
                        }
                        else
                        {
                            Database.Entity.DeviceBackend deviceBackendEntity = new Database.Entity.DeviceBackend()
                            {
                                Id = mappedid,
                                IMEI = iMEI,
                                MappedDateTime = DateTime.UtcNow
                            };
                            _service.AddDeviceBackend(deviceBackendEntity);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.LogInformation("AddMapping", ex);
            }
            return RedirectToAction("Edit", "Device", new { @id = iMEI });
           // return RedirectToAction(nameof(Edit),iMEI);
            // return Edit(iMEI);
        }

        // GET: DeviceController/Delete/5
        public ActionResult Delete(string id)
        {
            //try
            //{
            //    _service.DeleteDevice(id);
            //}
            //catch (Exception ex)
            //{
            //    _logger.LogInformation("Delete", ex);
            //}
            DeviceModel model = new DeviceModel();

            try
            {
                var deviceEntity = _service.GetDevice(id);
                if (deviceEntity != null)
                {
                    model.IMEI = deviceEntity.IMEI;
                    model.Model = deviceEntity.Model;
                    model.SIMCard = deviceEntity.SIMCard;
                    model.Enabled = deviceEntity.Enabled.ToString();
                }
            }
            catch (Exception ex)
            {

            }
            return View(model);
        }

        public ActionResult DeleteDeviceBackend(IDictionary<string, string> routeData)
        {
            string iMEI = routeData["IMEI"];
            Guid backendID = Guid.Parse(routeData["BackendID"]);
            try
            {

                if (!string.IsNullOrEmpty(iMEI) && backendID != Guid.Empty)
                    _service.DeleteDeviceBackend(iMEI, backendID);

            }
            catch (Exception ex)
            {
                _logger.LogInformation("DeleteDeviceBackend", ex);
            }
            // return RedirectToAction(nameof(Index));
            return RedirectToAction("Edit", "Device", new { @id = iMEI });
        }

        // POST: DeviceController/Delete/5
        [HttpPost]
        // [ValidateAntiForgeryToken]
        public ActionResult Delete(string id, IFormCollection collection)
        {
            try
            {
                _service.DeleteDevice(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}

