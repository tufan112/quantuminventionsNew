﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreDemoPOCs.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using CoreDemoPOCs.Service;
using Microsoft.AspNetCore.Http;
using CoreDemoPOCs.Database.Entity;

namespace CoreDemoPOCs.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly SignInManager<IdentityUser> _signinManager;
        private ILogger _logger;
        private IDevicesService _service;
        public AccountController(ILogger<AccountController> logger, IDevicesService service)
        {
            //_signinManager = signinManager;
            _logger = logger;
            _service = service;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Test()
        {

            try
            {
                User usr = new User()
                {
                    UserName = "admin",
                    Password = "admin",
                    Role = 0
                };
                _service.AddUser(usr);

            }
            catch (Exception ex)
            {

            }

            return Ok("Successfully created");
        }
        [HttpGet]
        public IActionResult Login(string returnUrl = "")
        {
            var model = new LoginViewModel { ReturnUrl = returnUrl };
            return View(model);
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = _service.Validuser(model.Username, model.Password);
                if (result)
                { 
                    HttpContext.Session.SetString("Username",model.Username);
                 
                    if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
                    {
                        return Redirect(model.ReturnUrl);
                    }
                    else
                    {
                        return RedirectToAction("Index", "Device");
                    }
                }
            }
            ModelState.AddModelError("", "Invalid login attempt");
            return View(model);
        }
    }
}
