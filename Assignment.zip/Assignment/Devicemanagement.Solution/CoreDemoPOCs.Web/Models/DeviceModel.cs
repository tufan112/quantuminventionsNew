﻿using CoreDemoPOCs.Database.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoreDemoPOCs.Web.Models
{
    public class DeviceModel
    {
       
        [Required]
        [MaxLength(20)]
        public string IMEI { get; set; }

       [Required]
       [MaxLength(50)]
        public string Model { get; set; }

        [Required]
        //[MaxLength(20)]
        public double SIMCard { get; set; }
        [Required]
        public string Enabled { get; set; }
        public Guid Mappedid { get; set; }         
        public List<Backend> backends { get; set; }
        public List<BackendModel> backendList { get; set; }
    }
}
