﻿using CoreDemoPOCs.Database.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Reflection;

namespace CoreDemoPOCs.Database
{
    public class SQLiteDBContext : DbContext
    {

        //public SQLiteDBContext(DbContextOptions<SQLiteDBContext> options)
        //   : base(options)
        //{
        //}
          public DbSet<Device> Devices { get; set; }
          public DbSet<Backend> Backends { get; set; }
          public DbSet<DeviceBackend> DeviceBackends { get; set; }
          public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DeviceBackend>()
                .HasKey(c => new { c.IMEI, c.Id });
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Filename=Tufan.db", options =>
            {
                options.MigrationsAssembly(Assembly.GetExecutingAssembly().FullName);
            });
            base.OnConfiguring(optionsBuilder);
        }
        //protected override void OnConfiguring(DbContextOptionsBuilder options)
        //    => options.UseSqlite("Data Source=sqlitedemo.db");
    }
}
