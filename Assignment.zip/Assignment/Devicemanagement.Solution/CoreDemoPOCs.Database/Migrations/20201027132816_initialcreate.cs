﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CoreDemoPOCs.Database.Migrations
{
    public partial class initialcreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Backends",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 20, nullable: true),
                    Address = table.Column<string>(maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Backends", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DeviceBackends",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    IMEI = table.Column<string>(nullable: true),
                    MappedDateTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeviceBackends", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Devices",
                columns: table => new
                {
                    IMEI = table.Column<string>(maxLength: 20, nullable: false),
                    Model = table.Column<string>(maxLength: 50, nullable: false),
                    SIMCard = table.Column<double>(maxLength: 20, nullable: false),
                    Enabled = table.Column<bool>(nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Devices", x => x.IMEI);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Backends");

            migrationBuilder.DropTable(
                name: "DeviceBackends");

            migrationBuilder.DropTable(
                name: "Devices");
        }
    }
}
