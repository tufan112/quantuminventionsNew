﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CoreDemoPOCs.Database.Entity
{
    public class Device
    {
        [Key]
        [Required]
        [MaxLength(20)]
        public string IMEI { get; set; }

        [Required]
        [MaxLength(50)]
        public string Model{ get; set; }

        [Required]
        [MaxLength(20)]
        public double SIMCard { get; set; }
        [Required]
        public bool	Enabled { get; set; }
        [Column(TypeName = "datetime2")]
        [Required]
        public DateTime	CreatedDate { get; set; }
        [Required]
        public string CreatedBy { get; set; }

    }
}
