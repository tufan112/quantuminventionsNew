﻿using CoreDemoPOCs.Database.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace CoreDemoPOCs.Service
{
    public interface IDevicesService
    {         
        List<Device> GetDevices();
        List<Backend> GetBackends();
        List<DeviceBackend> GetDeviceBackends();

        Device AddDevice(Device deviceItem);
        Backend AddBackend(Backend backendItem);
        User AddUser(User usrItem);
        DeviceBackend AddDeviceBackend(DeviceBackend dvBackendItem);
        DeviceBackend UpdateDeviceBackend(DeviceBackend dvBackendItem);
        Device UpdateDevice(string IMEI, Device deviceItem);
        Backend UpdateBackend(Guid Id, Backend backendItem);

        string DeleteDevice(string IMEI);
        bool DeleteDeviceBackend(string IMEI, Guid id);
        Device GetDevice(string IMEI);
        Backend GetBackend(Guid id);

        List<Backend> GetBackendOfDevice(string IMEI);
        bool Validuser(string username, string password);
        DeviceBackend GetDeviceBackend(string IMEI, Guid Id);
    }
}
