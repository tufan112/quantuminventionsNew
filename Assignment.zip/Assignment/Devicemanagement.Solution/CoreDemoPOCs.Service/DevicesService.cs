﻿using CoreDemoPOCs.Database;
using CoreDemoPOCs.Database.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CoreDemoPOCs.Service
{
    public class DevicesService : IDevicesService
    {
        private List<Device> _deviceItems;
        private SQLiteDBContext _context;
        public DevicesService()
        {
            //_deviceItems = new List<Device>();
            _context = new SQLiteDBContext();
            _context.Database.EnsureCreated();
        }

        public List<Device> GetDevices()
        {
            _deviceItems = new List<Device>();
            _deviceItems = _context.Devices?.ToList();
            return _deviceItems;
        }

        public List<Backend> GetBackends()
        {
            var backends = new List<Backend>();
            backends = _context.Backends?.ToList();
            return backends;
        }
        public List<DeviceBackend> GetDeviceBackends()
        {
            var devicebackend = new List<DeviceBackend>();
            devicebackend = _context.DeviceBackends?.ToList();
            return devicebackend;
        }
        public DeviceBackend GetDeviceBackend(string IMEI,Guid Id)
        {
           
          return  _context.DeviceBackends.Where(x => x.IMEI == IMEI && x.Id == Id).FirstOrDefault();
         
        }

        public Device GetDevice(string IMEI)
        {
            return _context.Devices.Where(x => x.IMEI == IMEI).FirstOrDefault();
        }

        public Device AddDevice(Device deviceItem)
        {
            _context.Add(deviceItem);
            _context.SaveChanges();
            return deviceItem;
        }
        public Backend AddBackend(Backend backendItem)
        {
            _context.Add(backendItem);
            _context.SaveChanges();
            return backendItem;
        }
        public User AddUser(User usrItem)
        {
            _context.Add(usrItem);
            _context.SaveChanges();
            return usrItem;
        }
        public DeviceBackend AddDeviceBackend(DeviceBackend dvBackendItem)
        {
            _context.Add(dvBackendItem);
            _context.SaveChanges();
            return dvBackendItem;

        }
        public DeviceBackend UpdateDeviceBackend(DeviceBackend dvBackendItem)
        {
            _context.Update(dvBackendItem);
            _context.SaveChanges();
            return dvBackendItem;

        }
        

        public Device UpdateDevice(string IMEI, Device deviceItem)
        {
            _context.Update(deviceItem);
            _context.SaveChanges();
            return deviceItem;
        }

        public Backend UpdateBackend(Guid Id, Backend backendItem)
        {
            var backendDetail = _context.Backends.Where(x => x.Id == Id).FirstOrDefault();
            if (backendDetail != null)
            {
                _context.Update(backendItem);
                _context.SaveChanges();
            }
            return backendItem;
        }

        public string DeleteDevice(string IMEI)
        {
            var fetchDevice = _context.Devices.Where(x => x.IMEI == IMEI).FirstOrDefault();
            if (fetchDevice == null) return null;
            _context.Remove(fetchDevice);
            _context.SaveChanges();
            return IMEI;
        }

        public bool DeleteDeviceBackend(string IMEI, Guid id)
        {
            try
            {
                var tt = _context.DeviceBackends.Where(x => x.IMEI == IMEI && x.Id == id).ToList();
                var fetchDeviceBackends = _context.DeviceBackends.Where(x => x.IMEI == IMEI && x.Id == id).FirstOrDefault();
                if (fetchDeviceBackends == null) return false;
                // _context.Remove<DeviceBackend>(fetchDeviceBackends);
                _context.DeviceBackends.Remove(fetchDeviceBackends);
                // _context.Remove(fetchDeviceBackends);
                //   _context.Entry(fetchDeviceBackends).State = EntityState.Deleted;
                _context.SaveChanges();
                return true;
            }   
            catch (Exception ex)
            {
                return false;
            }         

        }

        public Backend GetBackend(Guid id)
        {
            return _context.Backends.Where(x => x.Id == id).FirstOrDefault();
        }

        public List<Backend> GetBackendOfDevice(string IMEI)
        {
            var backend = new List<Backend>();
            backend = (from devback in _context.DeviceBackends
                       join bk in _context.Backends on devback.Id equals bk.Id
                       where devback.IMEI == IMEI
                       select new Backend()
                       {
                           Id = bk.Id,
                           Name = bk.Name,
                           Address = bk.Address
                       }).ToList();
            return backend;
        }

        public bool Validuser(string username, string password)
        {
            bool result = false;
            try
            {
                var usrData = _context.Users.Where(x => x.UserName == username && x.Password == password).FirstOrDefault();
                if (usrData != null)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                result = false;

            }
            return result;
        }
    }
}

